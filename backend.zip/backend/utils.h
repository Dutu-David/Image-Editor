//
// Created by jacopo on 08/05/21.
//

#ifndef IMAGE_EDITOR_UTILS_H
#define IMAGE_EDITOR_UTILS_H

int truncate0_255(int value);

int truncate_m100_100(int value);

int truncate0_100(int value);

#endif //IMAGE_EDITOR_UTILS_H
